# fancybox-modal
"Fancybox" modal for media popups

My example of the Fancybox modal. These are all the files I used, and even though it is working in production (http://tekleemedia.com), the modal in this example is broken right now. Not sure why yet.
